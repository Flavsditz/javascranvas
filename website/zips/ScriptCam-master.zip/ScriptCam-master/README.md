ScriptCam - use your webcam in Javascript JQuery
================================================

ScriptCam is a popular JQuery plugin to manipulate webcams. Take snapshots, detect movement and colors, record videoclips, generate animated GIFs, make thumbnails and organize one-to-one and one-to-many videochats using JavaScript on your own site.

Impress your clients and visitors with this multi-language and fully customizable library.

Please open our website to see the plugin in action: http://www.scriptcam.com

Due to security restrictions, ScriptCam can only be used on a webserver, not on a local machine.

Parts of this software make use of the ZXing library (https://code.google.com/p/zxing/).